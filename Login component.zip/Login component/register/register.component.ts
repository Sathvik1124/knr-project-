import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, HttpClientModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  error: string = '';
  showPassword: boolean = false;
  showConfirmPassword: boolean = false;
  isLoading: boolean = false;
  showErrorPopup = false;
  isHiding = false;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.formBuilder.group({
      fullName: ['', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(50),
        Validators.pattern(/^[a-zA-Z\s]*$/)
      ]],
      email: ['', [
        Validators.required,
        Validators.email,
        Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)
      ]],
      confirmPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator
    });
  }

  ngOnInit(): void {}

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleConfirmPasswordVisibility() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  getPasswordStrength(password: string): number {
    if (!password) return 0;
    
    let strength = 0;
    
    // Length check
    if (password.length >= 8) strength += 1;
    if (password.length >= 12) strength += 1;
    
    // Character type checks
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;
    
    return Math.min(strength, 5);
  }

  getPasswordStrengthText(strength: number): string {
    if (strength <= 2) return 'weak';
    if (strength <= 4) return 'medium';
    return 'strong';
  }

  getPasswordStrengthWidth(strength: number): string {
    return `${(strength / 5) * 100}%`;
  }

  getErrorMessage(controlName: string): string {
    const control = this.registerForm.get(controlName);
    if (!control) return '';

    if (control.hasError('required')) {
      return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} is required`;
    }
    if (control.hasError('email')) {
      return 'Please enter a valid email address';
    }
    if (control.hasError('minlength')) {
      const requiredLength = control.errors?.['minlength'].requiredLength;
      return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} must be at least ${requiredLength} characters`;
    }
    if (control.hasError('maxlength')) {
      const maxLength = control.errors?.['maxlength'].requiredLength;
      return `${controlName.charAt(0).toUpperCase() + controlName.slice(1)} must not exceed ${maxLength} characters`;
    }
    if (control.hasError('pattern')) {
      switch (controlName) {
        case 'fullName':
          return 'Name should only contain letters and spaces';
        case 'email':
          return 'Please enter a valid email address (e.g., example@domain.com)';
        case 'password':
          return 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character';
        default:
          return 'Invalid format';
      }
    }
    return '';
  }

  validateForm(): boolean {
    this.error = '';
    
    if (this.registerForm.invalid) {
      if (this.registerForm.hasError('passwordMismatch')) {
        this.error = 'Passwords do not match';
      } else {
        const firstError = Object.keys(this.registerForm.controls).find(key => 
          this.registerForm.get(key)?.errors
        );
        if (firstError) {
          this.error = this.getErrorMessage(firstError);
        } else {
          this.error = 'Please fill in all required fields correctly';
        }
      }
      return false;
    }
    return true;
  }

  showError(message: string) {
    this.error = message;
    this.showErrorPopup = true;
    this.isHiding = false;
  }

  closeErrorPopup() {
    this.isHiding = true;
    setTimeout(() => {
      this.showErrorPopup = false;
      this.isHiding = false;
    }, 300);
  }

  async onSubmit() {
    if (!this.validateForm()) {
      return;
    }

    const { fullName, email, password } = this.registerForm.value;
    this.isLoading = true;
    
    try {
      await this.authService.register(fullName, email, password);
      this.router.navigate(['/login']);
    } catch (error: any) {
      this.showError(error.message || 'Registration failed. Please try again.');
    } finally {
      this.isLoading = false;
    }
  }
} 