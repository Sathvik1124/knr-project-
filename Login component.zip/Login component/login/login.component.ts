import { Router } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { RoleSelectionComponent } from '../../components/role-selection/role-selection.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RoleSelectionComponent, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email = '';
  password = '';
  errorMessage = '';
  showRoleSelectionModal = false;
  showPassword = false;
  isLoading = false;

  constructor(
    @Inject(PLATFORM_ID) private platformId: Object,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      const email = sessionStorage.getItem('userEmail');
      const role = sessionStorage.getItem('selectedRole');
      if (email && role) {
        this.router.navigate([`/${role.split(':')[0].toLowerCase()}`]);
      }
    }
  }

  validateForm(): boolean {
    this.errorMessage = '';
    
    if (!this.email) {
      this.errorMessage = 'Please enter your email address';
      return false;
    }
    
    if (!this.email.includes('@')) {
      this.errorMessage = 'Please enter a valid email address';
      return false;
    }
    
    if (!this.password) {
      this.errorMessage = 'Please enter your password';
      return false;
    }
    
    if (this.password.length < 6) {
      this.errorMessage = 'Password must be at least 6 characters long';
      return false;
    }
    
    return true;
  }

  onSubmit(): void {
    if (!this.validateForm()) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    this.authService.login(this.email, this.password).subscribe({
      next: (response) => {
        this.isLoading = false;
        const roles = response.roles || [];
        if (isPlatformBrowser(this.platformId)) {
          sessionStorage.setItem('availableRoles', JSON.stringify(roles));
          sessionStorage.setItem('userEmail', this.email);
        }

        if (roles.length > 1) {
          this.showRoleSelectionModal = true;
        } else if (roles.length === 1) {
          if (isPlatformBrowser(this.platformId)) {
            sessionStorage.setItem('selectedRole', roles[0]);
          }
          this.authService.navigateBasedOnRole(roles[0]);
        } else {
          this.errorMessage = 'No roles assigned to this account';
        }
      },
      error: (error) => {
        this.isLoading = false;
        if (error.status === 401) {
          this.errorMessage = 'Invalid email or password';
        } else if (error.status === 0) {
          this.errorMessage = 'Unable to connect to the server. Please check your internet connection';
        } else {
          this.errorMessage = error.error?.message || 'An error occurred. Please try again';
        }
      }
    });
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }
}
