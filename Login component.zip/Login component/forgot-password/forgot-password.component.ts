import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  email: string = '';
  errorMessage: string = '';
  successMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  validateEmail(): boolean {
    this.errorMessage = '';
    
    if (!this.email) {
      this.errorMessage = 'Please enter your email address';
      return false;
    }
    
    if (!this.email.includes('@')) {
      this.errorMessage = 'Please enter a valid email address';
      return false;
    }
    
    return true;
  }

  onSubmit() {
    if (!this.validateEmail()) {
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';
    this.isLoading = true;

    this.authService.forgotPassword(this.email).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success === false) {
          this.errorMessage = response.message;
        } else {
          this.successMessage = 'Password reset link has been sent to your email';
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 3000);
        }
      },
      error: (error) => {
        this.isLoading = false;
        if (error.status === 404) {
          this.errorMessage = 'No account found with this email address';
        } else if (error.status === 0) {
          this.errorMessage = 'Unable to connect to the server. Please check your internet connection';
        } else {
          this.errorMessage = error.error?.message || 'Failed to send reset link. Please try again.';
        }
      }
    });
  }
} 